import { useCallback, useState } from 'react';
import {
  ExpoSpeechRecognitionModule,
  useSpeechRecognitionEvent,
} from 'expo-speech-recognition';

type VoiceSearchOptions = {
  onTranscript: (transcript: string) => void;
  language?: string;
};

export function useVoiceSearch({
  onTranscript,
  language = 'en-IN',
}: VoiceSearchOptions) {
  const [isListening, setIsListening] = useState(false);
  const [isAvailable, setIsAvailable] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useSpeechRecognitionEvent('start', () => {
    setIsListening(true);
    setError(null);
  });

  useSpeechRecognitionEvent('end', () => {
    setIsListening(false);
  });

  useSpeechRecognitionEvent('result', (event) => {
    const transcript = event.results?.[0]?.transcript?.trim();
    if (transcript) {
      setError(null);
      onTranscript(transcript);
    }
  });

  useSpeechRecognitionEvent('error', (event) => {
    setIsListening(false);
    if (event.error === 'aborted') return;

    const messages: Record<string, string> = {
      'not-allowed': 'Microphone or speech recognition permission was not granted. Enable it in your device settings and try again.',
      'service-not-allowed': 'Speech recognition is not available on this device. Check that a speech recognition service is installed and enabled.',
      'language-not-supported': `The selected speech language (${language}) is not supported by this device.`,
      'no-speech': 'No speech was detected. Please try speaking a little closer to the microphone.',
      'audio-capture': 'The microphone could not be started. Check that another app is not using it.',
      network: 'The device speech service could not complete recognition. Check your connection and try again.',
      busy: 'Speech recognition is busy. Please try again in a moment.',
    };
    setError(messages[event.error] ?? event.message ?? 'Voice search could not be started.');
  });

  const startOrStop = useCallback(async () => {
    setError(null);

    if (isListening) {
      ExpoSpeechRecognitionModule.stop();
      return;
    }

    try {
      const available = ExpoSpeechRecognitionModule.isRecognitionAvailable();
      setIsAvailable(available);
      if (!available) {
        setError('Speech recognition is not available. Please enable a speech recognition service on your device.');
        return;
      }

      const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if (!permission.granted) {
        setError('Microphone and speech recognition permission are required for voice search.');
        return;
      }

      ExpoSpeechRecognitionModule.start({
        lang: language,
        interimResults: true,
        maxAlternatives: 1,
        continuous: false,
        addsPunctuation: true,
        iosTaskHint: 'search',
      });
    } catch (startError) {
      setIsListening(false);
      setError(startError instanceof Error ? startError.message : 'Unable to start voice recognition.');
    }
  }, [isListening, language]);

  const clearError = useCallback(() => setError(null), []);

  return { isListening, isAvailable, error, startOrStop, clearError };
}
